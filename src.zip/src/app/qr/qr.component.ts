import { Component, OnInit } from '@angular/core';
import { QrCodeModule } from 'ng-qrcode';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from '@techiediaries/ngx-qrcode';
import {NgTinyUrlService} from 'ng-tiny-url';

@Component({
  selector: 'app-qr',
  templateUrl: './qr.component.html',
  styleUrls: ['./qr.component.css']
})

export class QrComponent implements OnInit {
   url=""
   value:any
   elementType:any
   correctionLevel:any;
   shortenUrl:any
  constructor(private tinyURL: NgTinyUrlService) { }
  ngOnInit(): void {
  }
 
  readData(event:any){
    this.url=event.target.value;
    if(this.isUrlValid(this.url))
      this.generateQr();
    else{
      alert("INVALID URL")
    }
  }
  isUrlValid(inputUrl: string) {
    var res = inputUrl.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
    if(res == null)
        return false;
    else
        return true;
}
  generateQr(){
      this.elementType = NgxQrcodeElementTypes.URL;
      this.correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
      this.value = this.url;
    this.tinyURL.shorten(this.url).subscribe(data=>{
      this.shortenUrl=data;
    })
  }
  downloadQR(qr:any){
    const parentElement = qr.qrcElement.nativeElement.querySelector("img").src;
    let blobData = this.convertBase64ToBlob(parentElement);
      const blob = new Blob([blobData], { type: "image/png" });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'Qrcode';
      link.click();
    }
  

  private convertBase64ToBlob(Base64Image: any) {
    const parts = Base64Image.split(';base64,');
    const imageType = parts[0].split(':')[1];
    const decodedData = window.atob(parts[1]);
    const uInt8Array = new Uint8Array(decodedData.length);
    for (let i = 0; i < decodedData.length; ++i) {
      uInt8Array[i] = decodedData.charCodeAt(i);
    }
    return new Blob([uInt8Array], { type: imageType });
  }

}